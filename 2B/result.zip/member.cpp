// KRZYSZTOF PIECHAL
#include "bitwise_operations.h"

bool Member(char *p, int n) {
  int temp = 0;
  Emplace(p, &temp);
  return n & temp;
}
