// KRZYSZTOF PIECHAL
#include "bitwise_operations.h"

bool Emptiness(int n) { return traverse_all(&n, 0, true, 0); }

bool Nonempty(int n) { return !Emptiness(n); }
